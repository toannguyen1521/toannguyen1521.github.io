@echo off
python "%~dp0permission_converter.py"
pause