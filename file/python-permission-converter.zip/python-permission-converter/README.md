# Permission Converter

A compact Python tool that quickly converts between system permission formats such as Input Permission, Octal Numbers (755, 644) and rwx notation in Linux.

## How to run the project

This project is very simple and does not require installing any external libraries. You just need to do the following:

1. Your computer must have **Python** (version 3.13 or later) installed.

2. Open the folder containing the project you just downloaded.

3. Run the permission.bat file in the folder.

4. A CMD window will appear. Simply type 6755 or rwxr-xr-x, press Enter, and the tool will immediately convert from Symbols to Octals and from Octals to Symbols for you.

5. When you're finished, press Ctrl + C to exit. The CMD window will display the message "Terminate batch job (Y/N)?", press "Y" to exit and press "N" to cancel the exit command.


![Demo Chương Trình](image/permission-picture.png)


## Features

* Converts formats Easy rights form between Octal --> Symbol